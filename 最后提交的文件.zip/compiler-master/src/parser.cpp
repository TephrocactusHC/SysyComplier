/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* "%code top" blocks.  */
#line 1 "src/parser.y"

    #include <iostream>
    #include <assert.h>
    #include <cstring>
    #include <stack>
    #include "parser.h"
    extern Ast ast;
    int yylex();
    int yyerror( char const * );
    ArrayType* arrayType;
    int idx;
    int paramNo = 0;
    int* arrayValue;

    

    std::stack<StmtNode*> whileStk;
    int whileCnt = 0;
    #include <iostream>
    using namespace std;

#line 90 "src/parser.cpp"




# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "parser.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_ID = 3,                         /* ID  */
  YYSYMBOL_INTEGER = 4,                    /* INTEGER  */
  YYSYMBOL_IF = 5,                         /* IF  */
  YYSYMBOL_ELSE = 6,                       /* ELSE  */
  YYSYMBOL_WHILE = 7,                      /* WHILE  */
  YYSYMBOL_FOR = 8,                        /* FOR  */
  YYSYMBOL_BREAK = 9,                      /* BREAK  */
  YYSYMBOL_CONTINUE = 10,                  /* CONTINUE  */
  YYSYMBOL_INT = 11,                       /* INT  */
  YYSYMBOL_VOID = 12,                      /* VOID  */
  YYSYMBOL_CONST = 13,                     /* CONST  */
  YYSYMBOL_FLOAT = 14,                     /* FLOAT  */
  YYSYMBOL_LPAREN = 15,                    /* LPAREN  */
  YYSYMBOL_RPAREN = 16,                    /* RPAREN  */
  YYSYMBOL_LBRACE = 17,                    /* LBRACE  */
  YYSYMBOL_RBRACE = 18,                    /* RBRACE  */
  YYSYMBOL_SEMICOLON = 19,                 /* SEMICOLON  */
  YYSYMBOL_COMMA = 20,                     /* COMMA  */
  YYSYMBOL_LBRACKET = 21,                  /* LBRACKET  */
  YYSYMBOL_RBRACKET = 22,                  /* RBRACKET  */
  YYSYMBOL_GETINT = 23,                    /* GETINT  */
  YYSYMBOL_PUTINT = 24,                    /* PUTINT  */
  YYSYMBOL_PUTCH = 25,                     /* PUTCH  */
  YYSYMBOL_GETCH = 26,                     /* GETCH  */
  YYSYMBOL_GETFLOAT = 27,                  /* GETFLOAT  */
  YYSYMBOL_PUTFLOAT = 28,                  /* PUTFLOAT  */
  YYSYMBOL_ASSIGN = 29,                    /* ASSIGN  */
  YYSYMBOL_LESS = 30,                      /* LESS  */
  YYSYMBOL_EQ = 31,                        /* EQ  */
  YYSYMBOL_MORE = 32,                      /* MORE  */
  YYSYMBOL_LESSQ = 33,                     /* LESSQ  */
  YYSYMBOL_MOREQ = 34,                     /* MOREQ  */
  YYSYMBOL_NOTEQ = 35,                     /* NOTEQ  */
  YYSYMBOL_MUL = 36,                       /* MUL  */
  YYSYMBOL_DIV = 37,                       /* DIV  */
  YYSYMBOL_MOD = 38,                       /* MOD  */
  YYSYMBOL_OR = 39,                        /* OR  */
  YYSYMBOL_AND = 40,                       /* AND  */
  YYSYMBOL_NOT = 41,                       /* NOT  */
  YYSYMBOL_ADD = 42,                       /* ADD  */
  YYSYMBOL_SUB = 43,                       /* SUB  */
  YYSYMBOL_RETURN = 44,                    /* RETURN  */
  YYSYMBOL_THEN = 45,                      /* THEN  */
  YYSYMBOL_YYACCEPT = 46,                  /* $accept  */
  YYSYMBOL_Program = 47,                   /* Program  */
  YYSYMBOL_Stmts = 48,                     /* Stmts  */
  YYSYMBOL_Stmt = 49,                      /* Stmt  */
  YYSYMBOL_ConstExp = 50,                  /* ConstExp  */
  YYSYMBOL_LVal = 51,                      /* LVal  */
  YYSYMBOL_AssignStmt = 52,                /* AssignStmt  */
  YYSYMBOL_BlockStmt = 53,                 /* BlockStmt  */
  YYSYMBOL_54_1 = 54,                      /* $@1  */
  YYSYMBOL_IfStmt = 55,                    /* IfStmt  */
  YYSYMBOL_WhileStmt = 56,                 /* WhileStmt  */
  YYSYMBOL_57_2 = 57,                      /* @2  */
  YYSYMBOL_BreakStmt = 58,                 /* BreakStmt  */
  YYSYMBOL_ContinueStmt = 59,              /* ContinueStmt  */
  YYSYMBOL_ReturnStmt = 60,                /* ReturnStmt  */
  YYSYMBOL_NullStmt = 61,                  /* NullStmt  */
  YYSYMBOL_Exp = 62,                       /* Exp  */
  YYSYMBOL_Cond = 63,                      /* Cond  */
  YYSYMBOL_AddExp = 64,                    /* AddExp  */
  YYSYMBOL_MulExp = 65,                    /* MulExp  */
  YYSYMBOL_UnaryExp = 66,                  /* UnaryExp  */
  YYSYMBOL_PrimaryExp = 67,                /* PrimaryExp  */
  YYSYMBOL_RelExp = 68,                    /* RelExp  */
  YYSYMBOL_EqExp = 69,                     /* EqExp  */
  YYSYMBOL_LAndExp = 70,                   /* LAndExp  */
  YYSYMBOL_LOrExp = 71,                    /* LOrExp  */
  YYSYMBOL_Type = 72,                      /* Type  */
  YYSYMBOL_DeclStmt = 73,                  /* DeclStmt  */
  YYSYMBOL_VarDeclStmt = 74,               /* VarDeclStmt  */
  YYSYMBOL_ConstDeclStmt = 75,             /* ConstDeclStmt  */
  YYSYMBOL_VarDecls = 76,                  /* VarDecls  */
  YYSYMBOL_ConstDecls = 77,                /* ConstDecls  */
  YYSYMBOL_VarDecl = 78,                   /* VarDecl  */
  YYSYMBOL_ConstDecl = 79,                 /* ConstDecl  */
  YYSYMBOL_FuncDef = 80,                   /* FuncDef  */
  YYSYMBOL_81_3 = 81,                      /* $@3  */
  YYSYMBOL_82_4 = 82,                      /* $@4  */
  YYSYMBOL_83_5 = 83,                      /* $@5  */
  YYSYMBOL_FuncParams = 84,                /* FuncParams  */
  YYSYMBOL_FuncParam = 85,                 /* FuncParam  */
  YYSYMBOL_Istream = 86,                   /* Istream  */
  YYSYMBOL_Ostream = 87,                   /* Ostream  */
  YYSYMBOL_ArrayIndex = 88,                /* ArrayIndex  */
  YYSYMBOL_FuncArrayIndex = 89,            /* FuncArrayIndex  */
  YYSYMBOL_ArrayValList = 90,              /* ArrayValList  */
  YYSYMBOL_ArrayVal = 91,                  /* ArrayVal  */
  YYSYMBOL_ConstArrayValList = 92,         /* ConstArrayValList  */
  YYSYMBOL_ConstArrayVal = 93,             /* ConstArrayVal  */
  YYSYMBOL_CallList = 94,                  /* CallList  */
  YYSYMBOL_FuncCallExp = 95                /* FuncCallExp  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_uint8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  72
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   469

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  46
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  50
/* YYNRULES -- Number of rules.  */
#define YYNRULES  115
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  208

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   300


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    61,    61,    67,    68,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    90,   108,   121,   135,   143,
     142,   153,   156,   159,   164,   164,   179,   184,   190,   201,
     214,   219,   226,   230,   235,   237,   243,   252,   254,   260,
     266,   275,   277,   283,   289,   299,   303,   307,   312,   319,
     321,   327,   333,   339,   350,   351,   355,   363,   365,   375,
     377,   384,   387,   390,   396,   398,   401,   405,   409,   411,
     415,   417,   426,   443,   459,   487,   516,   533,   550,   584,
     589,   584,   615,   614,   639,   648,   659,   667,   674,   699,
     707,   715,   726,   734,   742,   756,   759,   766,   769,   772,
     779,   782,   787,   790,   794,   799,   802,   807,   810,   814,
     838,   843,   851,   868,   889,   891
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "ID", "INTEGER", "IF",
  "ELSE", "WHILE", "FOR", "BREAK", "CONTINUE", "INT", "VOID", "CONST",
  "FLOAT", "LPAREN", "RPAREN", "LBRACE", "RBRACE", "SEMICOLON", "COMMA",
  "LBRACKET", "RBRACKET", "GETINT", "PUTINT", "PUTCH", "GETCH", "GETFLOAT",
  "PUTFLOAT", "ASSIGN", "LESS", "EQ", "MORE", "LESSQ", "MOREQ", "NOTEQ",
  "MUL", "DIV", "MOD", "OR", "AND", "NOT", "ADD", "SUB", "RETURN", "THEN",
  "$accept", "Program", "Stmts", "Stmt", "ConstExp", "LVal", "AssignStmt",
  "BlockStmt", "$@1", "IfStmt", "WhileStmt", "@2", "BreakStmt",
  "ContinueStmt", "ReturnStmt", "NullStmt", "Exp", "Cond", "AddExp",
  "MulExp", "UnaryExp", "PrimaryExp", "RelExp", "EqExp", "LAndExp",
  "LOrExp", "Type", "DeclStmt", "VarDeclStmt", "ConstDeclStmt", "VarDecls",
  "ConstDecls", "VarDecl", "ConstDecl", "FuncDef", "$@3", "$@4", "$@5",
  "FuncParams", "FuncParam", "Istream", "Ostream", "ArrayIndex",
  "FuncArrayIndex", "ArrayValList", "ArrayVal", "ConstArrayValList",
  "ConstArrayVal", "CallList", "FuncCallExp", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-165)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     226,    14,  -165,    10,    21,    34,    35,  -165,  -165,    46,
    -165,   426,  -165,  -165,    44,    55,    56,    62,    64,    65,
     426,   426,   426,   356,    88,   226,  -165,    60,  -165,  -165,
    -165,  -165,  -165,  -165,  -165,  -165,    71,     7,    31,  -165,
    -165,    32,    89,  -165,  -165,  -165,  -165,  -165,  -165,  -165,
     362,   426,    70,   426,   426,  -165,  -165,    90,  -165,    78,
     226,    79,   426,   426,    80,    81,   426,  -165,  -165,  -165,
    -165,    82,  -165,  -165,   426,  -165,   426,   426,   426,   426,
     426,   426,   426,   426,   426,    -2,    83,    84,  -165,    86,
      91,    76,     7,   426,    93,    32,   -13,    59,    61,    94,
      -1,    92,    95,  -165,   184,  -165,    97,    98,  -165,  -165,
     101,  -165,    99,    31,    31,  -165,  -165,  -165,     7,     7,
       7,     7,   103,   426,     9,  -165,   117,   426,  -165,  -165,
     100,   268,   426,   426,   426,   426,  -165,   426,    11,  -165,
      90,  -165,  -165,  -165,  -165,  -165,  -165,    46,  -165,   391,
      13,  -165,  -165,  -165,   105,   115,    32,    32,   -13,    59,
     226,  -165,   420,  -165,   107,   122,   111,   108,   298,  -165,
    -165,  -165,   226,  -165,   327,  -165,  -165,  -165,     2,  -165,
      46,  -165,    23,  -165,  -165,  -165,    58,  -165,   109,   426,
     426,   112,   107,  -165,  -165,   391,  -165,   420,  -165,   113,
    -165,   426,  -165,  -165,  -165,  -165,   114,  -165
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       0,    16,    47,     0,     0,     0,     0,    61,    62,     0,
      63,     0,    19,    30,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     2,     3,    45,     5,     6,
       7,     8,    10,    11,     9,    14,     0,    49,    34,    37,
      41,    32,     0,    12,    64,    65,    13,   114,   115,    48,
       0,     0,    17,     0,     0,    26,    27,     0,    45,     0,
       0,     0,     0,     0,     0,     0,     0,    44,    42,    43,
      29,     0,     1,     4,     0,    31,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    72,     0,    68,   112,   110,
       0,     0,    15,     0,     0,    54,    57,    59,    33,     0,
      76,     0,    70,    46,     0,    89,     0,     0,    90,    91,
       0,    28,     0,    35,    36,    38,    39,    40,    50,    51,
      52,    53,    79,     0,    74,    66,     0,     0,   113,    95,
       0,     0,     0,     0,     0,     0,    24,     0,     0,    67,
       0,    20,    92,    93,    94,    18,    82,     0,    73,     0,
      72,    69,   111,    96,    19,    21,    55,    56,    58,    60,
       0,    77,     0,    71,     0,     0,     0,    84,     0,   102,
      75,    22,     0,    25,     0,   107,    78,    83,    86,    80,
       0,   103,     0,   100,    23,   108,     0,   105,     0,     0,
       0,    88,     0,    85,   104,     0,   109,     0,    97,     0,
      87,     0,    81,   101,   106,    98,     0,    99
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -165,  -165,    69,   -23,    37,     1,  -165,  -155,  -165,  -165,
    -165,  -165,  -165,  -165,  -165,  -165,   -11,    85,   -37,     6,
      -5,  -165,   -48,     8,     5,  -165,    -6,  -165,  -165,  -165,
      17,    -7,  -165,  -165,  -165,  -165,  -165,  -165,   -36,  -165,
    -165,  -165,     3,  -165,  -165,  -147,  -165,  -164,   -55,  -165
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_uint8 yydefgoto[] =
{
       0,    24,    25,    26,    91,    58,    28,    29,    60,    30,
      31,   160,    32,    33,    34,    35,    36,    94,    37,    38,
      39,    40,    41,    96,    97,    98,    42,    43,    44,    45,
      86,   101,    87,   102,    46,   147,   192,   164,   166,   167,
      47,    48,   124,   191,   182,   170,   186,   176,    90,    49
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_uint8 yytable[] =
{
      59,    27,    73,    57,    52,    95,    95,   106,   107,   177,
     187,   110,    71,   122,    92,    67,    68,    69,   132,    51,
      51,   183,   133,   188,   189,    53,    27,   123,   137,    50,
      93,   190,    93,   204,    51,    51,    54,   202,   149,    89,
     162,   194,   123,   195,   118,   119,   120,   121,   203,    76,
      77,    89,    89,    55,    56,    89,    92,     7,     8,    61,
      10,    27,    81,   112,    82,    83,    84,    78,    79,    80,
      62,    63,   152,   115,   116,   117,   196,    64,   197,    65,
      66,    73,   113,   114,   156,   157,    95,    95,    72,    74,
      75,    93,    85,   100,   103,   105,   108,   109,   129,   134,
     135,   111,   125,   138,   126,    27,   127,   128,   155,   131,
     136,   139,   148,   142,   143,   140,    89,   144,   145,   146,
     150,   172,   153,   171,    12,   178,   161,   179,   180,   104,
     130,   198,    27,   163,   201,   205,   207,   173,   169,    99,
     159,   165,   158,   151,   193,     0,     0,     0,     0,   184,
       0,   175,     0,     0,     0,     0,     0,   169,     0,     0,
       0,    27,     0,   175,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    27,   165,     0,     0,     0,   199,   200,
       0,     0,     0,     0,   169,     0,   175,     1,     2,     3,
     206,     4,     0,     5,     6,     7,     8,     9,    10,    11,
       0,    12,   141,    13,     0,     0,     0,    14,    15,    16,
      17,    18,    19,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    20,    21,    22,    23,     1,
       2,     3,     0,     4,     0,     5,     6,     7,     8,     9,
      10,    11,     0,    12,     0,    13,     0,     0,     0,    14,
      15,    16,    17,    18,    19,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    20,    21,    22,
      23,     1,     2,     3,     0,     4,     0,     5,     6,     7,
       8,     9,    10,    11,     0,   154,     0,    13,     0,     0,
       0,    14,    15,    16,    17,    18,    19,     0,     0,     0,
       0,     1,     2,     0,     0,     0,     0,     0,     0,    20,
      21,    22,    23,    11,     0,   168,   181,     0,     0,     0,
       0,    14,    15,    16,    17,    18,    19,     0,     0,     0,
       1,     2,     0,     0,     0,     0,     0,     0,     0,    20,
      21,    22,    11,     0,   174,   185,     0,     0,     0,     0,
      14,    15,    16,    17,    18,    19,     0,     0,     0,     1,
       2,     0,     0,     0,     0,     1,     2,     0,    20,    21,
      22,    11,     0,     0,     0,    70,     0,    11,    88,    14,
      15,    16,    17,    18,    19,    14,    15,    16,    17,    18,
      19,     0,     0,     0,     1,     2,     0,    20,    21,    22,
       0,     0,     0,    20,    21,    22,    11,     0,   168,     0,
       0,     0,     0,     0,    14,    15,    16,    17,    18,    19,
       0,     0,     0,     1,     2,     0,     0,     0,     0,     1,
       2,     0,    20,    21,    22,    11,     0,   174,     0,     0,
       0,    11,     0,    14,    15,    16,    17,    18,    19,    14,
      15,    16,    17,    18,    19,     0,     0,     0,     0,     0,
       0,    20,    21,    22,     0,     0,     0,    20,    21,    22
};

static const yytype_int16 yycheck[] =
{
      11,     0,    25,     9,     1,    53,    54,    62,    63,   164,
     174,    66,    23,    15,    51,    20,    21,    22,    31,    21,
      21,   168,    35,    21,    22,    15,    25,    29,    29,    15,
      21,    29,    21,   197,    21,    21,    15,   192,    29,    50,
      29,    18,    29,    20,    81,    82,    83,    84,   195,    42,
      43,    62,    63,    19,    19,    66,    93,    11,    12,    15,
      14,    60,    30,    74,    32,    33,    34,    36,    37,    38,
      15,    15,   127,    78,    79,    80,    18,    15,    20,    15,
      15,   104,    76,    77,   132,   133,   134,   135,     0,    29,
      19,    21,     3,     3,    16,    16,    16,    16,    22,    40,
      39,    19,    19,   100,    20,   104,    20,    16,   131,    16,
      16,    19,   123,    16,    16,    20,   127,    16,    19,    16,
       3,     6,    22,    18,    17,     3,   137,    16,    20,    60,
      93,    22,   131,   140,    22,    22,    22,   160,   149,    54,
     135,   147,   134,   126,   180,    -1,    -1,    -1,    -1,   172,
      -1,   162,    -1,    -1,    -1,    -1,    -1,   168,    -1,    -1,
      -1,   160,    -1,   174,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   172,   180,    -1,    -1,    -1,   189,   190,
      -1,    -1,    -1,    -1,   195,    -1,   197,     3,     4,     5,
     201,     7,    -1,     9,    10,    11,    12,    13,    14,    15,
      -1,    17,    18,    19,    -1,    -1,    -1,    23,    24,    25,
      26,    27,    28,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    41,    42,    43,    44,     3,
       4,     5,    -1,     7,    -1,     9,    10,    11,    12,    13,
      14,    15,    -1,    17,    -1,    19,    -1,    -1,    -1,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    41,    42,    43,
      44,     3,     4,     5,    -1,     7,    -1,     9,    10,    11,
      12,    13,    14,    15,    -1,    17,    -1,    19,    -1,    -1,
      -1,    23,    24,    25,    26,    27,    28,    -1,    -1,    -1,
      -1,     3,     4,    -1,    -1,    -1,    -1,    -1,    -1,    41,
      42,    43,    44,    15,    -1,    17,    18,    -1,    -1,    -1,
      -1,    23,    24,    25,    26,    27,    28,    -1,    -1,    -1,
       3,     4,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    41,
      42,    43,    15,    -1,    17,    18,    -1,    -1,    -1,    -1,
      23,    24,    25,    26,    27,    28,    -1,    -1,    -1,     3,
       4,    -1,    -1,    -1,    -1,     3,     4,    -1,    41,    42,
      43,    15,    -1,    -1,    -1,    19,    -1,    15,    16,    23,
      24,    25,    26,    27,    28,    23,    24,    25,    26,    27,
      28,    -1,    -1,    -1,     3,     4,    -1,    41,    42,    43,
      -1,    -1,    -1,    41,    42,    43,    15,    -1,    17,    -1,
      -1,    -1,    -1,    -1,    23,    24,    25,    26,    27,    28,
      -1,    -1,    -1,     3,     4,    -1,    -1,    -1,    -1,     3,
       4,    -1,    41,    42,    43,    15,    -1,    17,    -1,    -1,
      -1,    15,    -1,    23,    24,    25,    26,    27,    28,    23,
      24,    25,    26,    27,    28,    -1,    -1,    -1,    -1,    -1,
      -1,    41,    42,    43,    -1,    -1,    -1,    41,    42,    43
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,     3,     4,     5,     7,     9,    10,    11,    12,    13,
      14,    15,    17,    19,    23,    24,    25,    26,    27,    28,
      41,    42,    43,    44,    47,    48,    49,    51,    52,    53,
      55,    56,    58,    59,    60,    61,    62,    64,    65,    66,
      67,    68,    72,    73,    74,    75,    80,    86,    87,    95,
      15,    21,    88,    15,    15,    19,    19,    72,    51,    62,
      54,    15,    15,    15,    15,    15,    15,    66,    66,    66,
      19,    62,     0,    49,    29,    19,    42,    43,    36,    37,
      38,    30,    32,    33,    34,     3,    76,    78,    16,    62,
      94,    50,    64,    21,    63,    68,    69,    70,    71,    63,
       3,    77,    79,    16,    48,    16,    94,    94,    16,    16,
      94,    19,    62,    65,    65,    66,    66,    66,    64,    64,
      64,    64,    15,    29,    88,    19,    20,    20,    16,    22,
      50,    16,    31,    35,    40,    39,    16,    29,    88,    19,
      20,    18,    16,    16,    16,    19,    16,    81,    62,    29,
       3,    76,    94,    22,    17,    49,    68,    68,    69,    70,
      57,    62,    29,    77,    83,    72,    84,    85,    17,    62,
      91,    18,     6,    49,    17,    62,    93,    53,     3,    16,
      20,    18,    90,    91,    49,    18,    92,    93,    21,    22,
      29,    89,    82,    84,    18,    20,    18,    20,    22,    62,
      62,    22,    53,    91,    93,    22,    62,    22
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    46,    47,    48,    48,    49,    49,    49,    49,    49,
      49,    49,    49,    49,    49,    50,    51,    51,    52,    54,
      53,    55,    55,    55,    57,    56,    58,    59,    60,    60,
      61,    61,    62,    63,    64,    64,    64,    65,    65,    65,
      65,    66,    66,    66,    66,    67,    67,    67,    67,    68,
      68,    68,    68,    68,    69,    69,    69,    70,    70,    71,
      71,    72,    72,    72,    73,    73,    74,    75,    76,    76,
      77,    77,    78,    78,    78,    78,    79,    79,    79,    81,
      82,    80,    83,    80,    84,    84,    85,    85,    85,    86,
      86,    86,    87,    87,    87,    88,    88,    89,    89,    89,
      90,    90,    91,    91,    91,    92,    92,    93,    93,    93,
      94,    94,    95,    95,    95,    95
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     2,     4,     0,
       4,     5,     6,     7,     0,     6,     2,     2,     3,     2,
       1,     2,     1,     1,     1,     3,     3,     1,     3,     3,
       3,     1,     2,     2,     2,     1,     3,     1,     1,     1,
       3,     3,     3,     3,     1,     3,     3,     1,     3,     1,
       3,     1,     1,     1,     1,     1,     3,     4,     1,     3,
       1,     3,     1,     3,     2,     4,     1,     3,     4,     0,
       0,     8,     0,     6,     1,     3,     2,     4,     3,     3,
       3,     3,     4,     4,     4,     3,     4,     2,     3,     4,
       1,     3,     1,     2,     3,     1,     3,     1,     2,     3,
       1,     3,     3,     4,     1,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* Program: Stmts  */
#line 61 "src/parser.y"
            {
        ast.setRoot((yyvsp[0].stmttype));
    }
#line 1374 "src/parser.cpp"
    break;

  case 3: /* Stmts: Stmt  */
#line 67 "src/parser.y"
           {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1380 "src/parser.cpp"
    break;

  case 4: /* Stmts: Stmts Stmt  */
#line 68 "src/parser.y"
                {
        (yyval.stmttype) = new SeqNode((yyvsp[-1].stmttype), (yyvsp[0].stmttype));
    }
#line 1388 "src/parser.cpp"
    break;

  case 5: /* Stmt: AssignStmt  */
#line 73 "src/parser.y"
                 {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1394 "src/parser.cpp"
    break;

  case 6: /* Stmt: BlockStmt  */
#line 74 "src/parser.y"
                {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1400 "src/parser.cpp"
    break;

  case 7: /* Stmt: IfStmt  */
#line 75 "src/parser.y"
             {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1406 "src/parser.cpp"
    break;

  case 8: /* Stmt: WhileStmt  */
#line 76 "src/parser.y"
                {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1412 "src/parser.cpp"
    break;

  case 9: /* Stmt: ReturnStmt  */
#line 77 "src/parser.y"
                 {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1418 "src/parser.cpp"
    break;

  case 10: /* Stmt: BreakStmt  */
#line 78 "src/parser.y"
                {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1424 "src/parser.cpp"
    break;

  case 11: /* Stmt: ContinueStmt  */
#line 79 "src/parser.y"
                   {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1430 "src/parser.cpp"
    break;

  case 12: /* Stmt: DeclStmt  */
#line 80 "src/parser.y"
               {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1436 "src/parser.cpp"
    break;

  case 13: /* Stmt: FuncDef  */
#line 81 "src/parser.y"
              {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1442 "src/parser.cpp"
    break;

  case 14: /* Stmt: NullStmt  */
#line 82 "src/parser.y"
               {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1448 "src/parser.cpp"
    break;

  case 15: /* ConstExp: AddExp  */
#line 90 "src/parser.y"
             {(yyval.exprtype) = (yyvsp[0].exprtype);}
#line 1454 "src/parser.cpp"
    break;

  case 16: /* LVal: ID  */
#line 108 "src/parser.y"
         {
        SymbolEntry *se;
        se = identifiers->lookup((yyvsp[0].strtype));
        if(se == nullptr)
        {
            fprintf(stderr, "identifier \"%s\" is undefined\n", (char*)(yyvsp[0].strtype));
            delete [](char*)(yyvsp[0].strtype);
            //exit(EXIT_FAILURE);
            assert(se != nullptr);
        }
        (yyval.exprtype) = new Id(se);
        delete [](yyvsp[0].strtype);
    }
#line 1472 "src/parser.cpp"
    break;

  case 17: /* LVal: ID ArrayIndex  */
#line 121 "src/parser.y"
                    {
        SymbolEntry* se;
        se = identifiers->lookup((yyvsp[-1].strtype));
        if(se==nullptr) {
            fprintf(stderr, "Variable \"%s\" has been used before definition\n", (char*)(yyvsp[-1].strtype));
            exit(EXIT_FAILURE);
        }
        (yyval.exprtype) = new Id(se, (yyvsp[0].exprtype));
        delete [](yyvsp[-1].strtype);
    }
#line 1487 "src/parser.cpp"
    break;

  case 18: /* AssignStmt: LVal ASSIGN Exp SEMICOLON  */
#line 135 "src/parser.y"
                             {
        (yyval.stmttype) = new AssignStmt((yyvsp[-3].exprtype), (yyvsp[-1].exprtype));
    }
#line 1495 "src/parser.cpp"
    break;

  case 19: /* $@1: %empty  */
#line 143 "src/parser.y"
        {identifiers = new SymbolTable(identifiers);}
#line 1501 "src/parser.cpp"
    break;

  case 20: /* BlockStmt: LBRACE $@1 Stmts RBRACE  */
#line 145 "src/parser.y"
        {
            (yyval.stmttype) = new CompoundStmt((yyvsp[-1].stmttype));
            SymbolTable *top = identifiers;
            identifiers = identifiers->getPrev();
            delete top;
        }
#line 1512 "src/parser.cpp"
    break;

  case 21: /* IfStmt: IF LPAREN Cond RPAREN Stmt  */
#line 153 "src/parser.y"
                                            {
        (yyval.stmttype) = new IfStmt((yyvsp[-2].exprtype), (yyvsp[0].stmttype));
    }
#line 1520 "src/parser.cpp"
    break;

  case 22: /* IfStmt: IF LPAREN Cond RPAREN LBRACE RBRACE  */
#line 156 "src/parser.y"
                                          {
        (yyval.stmttype) = new IfStmt((yyvsp[-3].exprtype),nullptr);
    }
#line 1528 "src/parser.cpp"
    break;

  case 23: /* IfStmt: IF LPAREN Cond RPAREN Stmt ELSE Stmt  */
#line 159 "src/parser.y"
                                           {
        (yyval.stmttype) = new IfElseStmt((yyvsp[-4].exprtype), (yyvsp[-2].stmttype), (yyvsp[0].stmttype));
    }
#line 1536 "src/parser.cpp"
    break;

  case 24: /* @2: %empty  */
#line 164 "src/parser.y"
                               {
        whileCnt ++;
        WhileStmt *whileNode = new WhileStmt((yyvsp[-1].exprtype));
        (yyval.stmttype) = whileNode;
        whileStk.push(whileNode);
    }
#line 1547 "src/parser.cpp"
    break;

  case 25: /* WhileStmt: WHILE LPAREN Cond RPAREN @2 Stmt  */
#line 170 "src/parser.y"
         {
        StmtNode *whileNode = (yyvsp[-1].stmttype); 
        ((WhileStmt*)whileNode)->setStmt((yyvsp[0].stmttype));
        (yyval.stmttype)=whileNode;
        whileStk.pop();
        whileCnt--;
    }
#line 1559 "src/parser.cpp"
    break;

  case 26: /* BreakStmt: BREAK SEMICOLON  */
#line 179 "src/parser.y"
                      {
        (yyval.stmttype) = new BreakStmt(whileStk.top());
    }
#line 1567 "src/parser.cpp"
    break;

  case 27: /* ContinueStmt: CONTINUE SEMICOLON  */
#line 184 "src/parser.y"
                         {
        (yyval.stmttype) = new ContinueStmt(whileStk.top());
    }
#line 1575 "src/parser.cpp"
    break;

  case 28: /* ReturnStmt: RETURN Exp SEMICOLON  */
#line 190 "src/parser.y"
                        {  //有返回值 setRet()-》isret==true;
        Type* t= current->getType();//t是一个函数类型
        if(dynamic_cast<FunctionType*>(t)->getRetType()!=TypeSystem::intType){
            fprintf(stderr,"error: return value's type and the function's type do not match\n");
            exit(EXIT_FAILURE);
        }else{
            dynamic_cast<FunctionType*>(t)->setRet();
            (yyval.stmttype) = new ReturnStmt((yyvsp[-1].exprtype));
        }
    }
#line 1590 "src/parser.cpp"
    break;

  case 29: /* ReturnStmt: RETURN SEMICOLON  */
#line 201 "src/parser.y"
                    {    //没有返回值，
        Type* t= current->getType();
        if(dynamic_cast<FunctionType*>(t)->getRetType()==TypeSystem::intType){
            fprintf(stderr,"lack return value\n");
            exit(EXIT_FAILURE);
        }else{
            (yyval.stmttype) = new ReturnStmt(nullptr);
        }        
    }
#line 1604 "src/parser.cpp"
    break;

  case 30: /* NullStmt: SEMICOLON  */
#line 215 "src/parser.y"
    {
        (yyval.stmttype)=new NullStmt(nullptr);
    }
#line 1612 "src/parser.cpp"
    break;

  case 31: /* NullStmt: Exp SEMICOLON  */
#line 220 "src/parser.y"
    {
        (yyval.stmttype)=new NullStmt((yyvsp[-1].exprtype));
    }
#line 1620 "src/parser.cpp"
    break;

  case 32: /* Exp: RelExp  */
#line 226 "src/parser.y"
           {(yyval.exprtype) = (yyvsp[0].exprtype);}
#line 1626 "src/parser.cpp"
    break;

  case 33: /* Cond: LOrExp  */
#line 230 "src/parser.y"
           {(yyval.exprtype) = (yyvsp[0].exprtype);}
#line 1632 "src/parser.cpp"
    break;

  case 34: /* AddExp: MulExp  */
#line 235 "src/parser.y"
           {(yyval.exprtype) = (yyvsp[0].exprtype);}
#line 1638 "src/parser.cpp"
    break;

  case 35: /* AddExp: AddExp ADD MulExp  */
#line 238 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::ADD, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1647 "src/parser.cpp"
    break;

  case 36: /* AddExp: AddExp SUB MulExp  */
#line 244 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::SUB, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1656 "src/parser.cpp"
    break;

  case 37: /* MulExp: UnaryExp  */
#line 252 "src/parser.y"
             {(yyval.exprtype) = (yyvsp[0].exprtype);}
#line 1662 "src/parser.cpp"
    break;

  case 38: /* MulExp: MulExp MUL UnaryExp  */
#line 255 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::MUL, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1671 "src/parser.cpp"
    break;

  case 39: /* MulExp: MulExp DIV UnaryExp  */
#line 261 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::DIV, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1680 "src/parser.cpp"
    break;

  case 40: /* MulExp: MulExp MOD UnaryExp  */
#line 267 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::MOD, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1689 "src/parser.cpp"
    break;

  case 41: /* UnaryExp: PrimaryExp  */
#line 275 "src/parser.y"
               {(yyval.exprtype)=(yyvsp[0].exprtype);}
#line 1695 "src/parser.cpp"
    break;

  case 42: /* UnaryExp: ADD UnaryExp  */
#line 278 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new UnaryExpr(se, UnaryExpr::ADD, (yyvsp[0].exprtype));
    }
#line 1704 "src/parser.cpp"
    break;

  case 43: /* UnaryExp: SUB UnaryExp  */
#line 284 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new UnaryExpr(se, UnaryExpr::SUB, (yyvsp[0].exprtype));
    }
#line 1713 "src/parser.cpp"
    break;

  case 44: /* UnaryExp: NOT UnaryExp  */
#line 290 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new UnaryExpr(se, UnaryExpr::NOT, (yyvsp[0].exprtype));
    }
#line 1722 "src/parser.cpp"
    break;

  case 45: /* PrimaryExp: LVal  */
#line 299 "src/parser.y"
         {
        (yyval.exprtype) = (yyvsp[0].exprtype);
    }
#line 1730 "src/parser.cpp"
    break;

  case 46: /* PrimaryExp: LPAREN Exp RPAREN  */
#line 303 "src/parser.y"
                      {
        (yyval.exprtype)=(yyvsp[-1].exprtype);
    }
#line 1738 "src/parser.cpp"
    break;

  case 47: /* PrimaryExp: INTEGER  */
#line 307 "src/parser.y"
            {
        SymbolEntry *se = new ConstantSymbolEntry(TypeSystem::intType, (yyvsp[0].itype));
        (yyval.exprtype) = new Constant(se);
    }
#line 1747 "src/parser.cpp"
    break;

  case 48: /* PrimaryExp: FuncCallExp  */
#line 312 "src/parser.y"
               {
        (yyval.exprtype)=(yyvsp[0].exprtype);
    }
#line 1755 "src/parser.cpp"
    break;

  case 49: /* RelExp: AddExp  */
#line 319 "src/parser.y"
           {(yyval.exprtype) = (yyvsp[0].exprtype);}
#line 1761 "src/parser.cpp"
    break;

  case 50: /* RelExp: RelExp LESS AddExp  */
#line 322 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::LESS, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1770 "src/parser.cpp"
    break;

  case 51: /* RelExp: RelExp MORE AddExp  */
#line 328 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::MORE, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1779 "src/parser.cpp"
    break;

  case 52: /* RelExp: RelExp LESSQ AddExp  */
#line 334 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::LESSQ, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1788 "src/parser.cpp"
    break;

  case 53: /* RelExp: RelExp MOREQ AddExp  */
#line 340 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::MOREQ, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1797 "src/parser.cpp"
    break;

  case 54: /* EqExp: RelExp  */
#line 350 "src/parser.y"
             {(yyval.exprtype) = (yyvsp[0].exprtype);}
#line 1803 "src/parser.cpp"
    break;

  case 55: /* EqExp: EqExp EQ RelExp  */
#line 351 "src/parser.y"
                      {
        SymbolEntry* se = new TemporarySymbolEntry(TypeSystem::boolType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::EQ, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1812 "src/parser.cpp"
    break;

  case 56: /* EqExp: EqExp NOTEQ RelExp  */
#line 355 "src/parser.y"
                         {
        SymbolEntry* se = new TemporarySymbolEntry(TypeSystem::boolType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::NOTEQ, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1821 "src/parser.cpp"
    break;

  case 57: /* LAndExp: EqExp  */
#line 363 "src/parser.y"
          {(yyval.exprtype) = (yyvsp[0].exprtype);}
#line 1827 "src/parser.cpp"
    break;

  case 58: /* LAndExp: LAndExp AND EqExp  */
#line 366 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::AND, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1836 "src/parser.cpp"
    break;

  case 59: /* LOrExp: LAndExp  */
#line 375 "src/parser.y"
            {(yyval.exprtype) = (yyvsp[0].exprtype);}
#line 1842 "src/parser.cpp"
    break;

  case 60: /* LOrExp: LOrExp OR LAndExp  */
#line 378 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::intType, SymbolTable::getLabel());
        (yyval.exprtype) = new BinaryExpr(se, BinaryExpr::OR, (yyvsp[-2].exprtype), (yyvsp[0].exprtype));
    }
#line 1851 "src/parser.cpp"
    break;

  case 61: /* Type: INT  */
#line 384 "src/parser.y"
          {
        (yyval.type) = TypeSystem::intType;
    }
#line 1859 "src/parser.cpp"
    break;

  case 62: /* Type: VOID  */
#line 387 "src/parser.y"
           {
        (yyval.type) = TypeSystem::voidType;
    }
#line 1867 "src/parser.cpp"
    break;

  case 63: /* Type: FLOAT  */
#line 390 "src/parser.y"
            {
        (yyval.type) = TypeSystem::floatType;
    }
#line 1875 "src/parser.cpp"
    break;

  case 64: /* DeclStmt: VarDeclStmt  */
#line 396 "src/parser.y"
                {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1881 "src/parser.cpp"
    break;

  case 65: /* DeclStmt: ConstDeclStmt  */
#line 398 "src/parser.y"
                  {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1887 "src/parser.cpp"
    break;

  case 66: /* VarDeclStmt: Type VarDecls SEMICOLON  */
#line 401 "src/parser.y"
                             {
        (yyval.stmttype)=(yyvsp[-1].stmttype);
    }
#line 1895 "src/parser.cpp"
    break;

  case 67: /* ConstDeclStmt: CONST Type ConstDecls SEMICOLON  */
#line 405 "src/parser.y"
                                     {
        (yyval.stmttype)=(yyvsp[-1].stmttype);
    }
#line 1903 "src/parser.cpp"
    break;

  case 68: /* VarDecls: VarDecl  */
#line 409 "src/parser.y"
              {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1909 "src/parser.cpp"
    break;

  case 69: /* VarDecls: VarDecl COMMA VarDecls  */
#line 411 "src/parser.y"
                           {
        (yyval.stmttype) = new VarDecls((yyvsp[-2].stmttype), (yyvsp[0].stmttype));
    }
#line 1917 "src/parser.cpp"
    break;

  case 70: /* ConstDecls: ConstDecl  */
#line 415 "src/parser.y"
                {(yyval.stmttype)=(yyvsp[0].stmttype);}
#line 1923 "src/parser.cpp"
    break;

  case 71: /* ConstDecls: ConstDecl COMMA ConstDecls  */
#line 417 "src/parser.y"
                               {
        (yyval.stmttype) = new ConstDecls((yyvsp[-2].stmttype), (yyvsp[0].stmttype));
    }
#line 1931 "src/parser.cpp"
    break;

  case 72: /* VarDecl: ID  */
#line 426 "src/parser.y"
       {
        SymbolEntry *se;
        se = identifiers->lookup((yyvsp[0].strtype));
       if(se!=nullptr&&dynamic_cast<IdentifierSymbolEntry*>(se)->getScope()==identifiers->getLevel()){
            fprintf(stderr,"identifier \"%s\" is redefined\n", (char*)(yyvsp[0].strtype));
            exit(EXIT_FAILURE);
            delete [](char*)(yyvsp[0].strtype);
            assert(se != nullptr);
        }else{
            se = new IdentifierSymbolEntry(TypeSystem::intType, (yyvsp[0].strtype), identifiers->getLevel());
            identifiers->install((yyvsp[0].strtype), se);
            (yyval.stmttype) = new VarDecl(new Id(se),nullptr);
            delete [](yyvsp[0].strtype);
        
    }
    }
#line 1952 "src/parser.cpp"
    break;

  case 73: /* VarDecl: ID ASSIGN Exp  */
#line 443 "src/parser.y"
                   {
        SymbolEntry *se;
        se = identifiers->lookup((yyvsp[-2].strtype));
         if(se!=nullptr&&dynamic_cast<IdentifierSymbolEntry*>(se)->getScope()==identifiers->getLevel()){
            fprintf(stderr,"identifier \"%s\" is redefined\n", (char*)(yyvsp[-2].strtype));
            delete [](char*)(yyvsp[-2].strtype);
            assert(se != nullptr);
        }else{ 
            //fprintf(stderr,"identifier \"%s\" is defined1\n", (char*)$1);
            se = new IdentifierSymbolEntry(TypeSystem::intType, (yyvsp[-2].strtype), identifiers->getLevel());
             ((IdentifierSymbolEntry*)se)->setValue((yyvsp[0].exprtype)->getValue());
            identifiers->install((yyvsp[-2].strtype), se);
            (yyval.stmttype) = new VarDecl(new Id(se),(yyvsp[0].exprtype));
            delete [](yyvsp[-2].strtype);
        }
     }
#line 1973 "src/parser.cpp"
    break;

  case 74: /* VarDecl: ID ArrayIndex  */
#line 459 "src/parser.y"
                     {
        SymbolEntry* se;
        ExprNode* temp = (yyvsp[0].exprtype);
        std::vector<int> vecIdx;
        while (temp) {
            vecIdx.push_back(temp->getValue());
            temp = (ExprNode*)(temp->getNext());
        }
        Type *type = TypeSystem::intType;
        Type* temp1;
        while(!vecIdx.empty()){
            temp1 = new ArrayType(type, vecIdx.back());
            if(type->isArray())
                ((ArrayType*)type)->setArrayType(temp1);
            type = temp1;
            vecIdx.pop_back();
        }


        arrayType = (ArrayType*)type;
        se = new IdentifierSymbolEntry(type, (yyvsp[-1].strtype), identifiers->getLevel());
        ((IdentifierSymbolEntry*)se)->setAllZero();
        int *p = new int[type->getSize()];  //设置整型空间 即长度*大小
        ((IdentifierSymbolEntry*)se)->setArrayValue(p);
        identifiers->install((yyvsp[-1].strtype), se);
        (yyval.stmttype) = new VarDecl(new Id(se));
        delete [](yyvsp[-1].strtype);
    }
#line 2006 "src/parser.cpp"
    break;

  case 75: /* VarDecl: ID ArrayIndex ASSIGN ArrayVal  */
#line 487 "src/parser.y"
                                    {
        SymbolEntry* se;
        ExprNode* temp = (yyvsp[-2].exprtype);
        std::vector<int> vecIdx;
        while (temp) {
            vecIdx.push_back(temp->getValue());
            temp = (ExprNode*)(temp->getNext());
        }
        Type *type;
        while (!vecIdx.empty()) {
            type = new ArrayType(TypeSystem::intType, vecIdx.back());
            vecIdx.pop_back();
        }
        arrayType = (ArrayType*)type;
        se = new IdentifierSymbolEntry(type, (yyvsp[-3].strtype), identifiers->getLevel());
        int *p = new int[type->getSize()];  //设置整型空间 即长度*大小
        ((IdentifierSymbolEntry*)se)->setArrayValue(p);
        identifiers->install((yyvsp[-3].strtype), se);
        
        /*if(!identifiers->install($1, se)){
            fprintf(stderr, "Variable \"%s\" redefinition\n", (char*)$1);
            exit(EXIT_FAILURE);
        }*/
        (yyval.stmttype) = new VarDecl(new Id(se), (yyvsp[0].exprtype));
        delete [](yyvsp[-3].strtype);
    }
#line 2037 "src/parser.cpp"
    break;

  case 76: /* ConstDecl: ID  */
#line 516 "src/parser.y"
       {
        SymbolEntry *se;
        se = identifiers->lookup((yyvsp[0].strtype));
        if(se!=nullptr&&dynamic_cast<IdentifierSymbolEntry*>(se)->getScope()==identifiers->getLevel()){
            fprintf(stderr,"identifier \"%s\" is redefined\n", (char*)(yyvsp[0].strtype));
            delete [](char*)(yyvsp[0].strtype);
            assert(se != nullptr);
        }else{
            se = new IdentifierSymbolEntry(TypeSystem::intType, (yyvsp[0].strtype), identifiers->getLevel());
            //se->setConstant();
            identifiers->install((yyvsp[0].strtype), se);
            
            (yyval.stmttype) = new ConstDecl(new Id(se),nullptr);
            delete [](yyvsp[0].strtype);
        }
    }
#line 2058 "src/parser.cpp"
    break;

  case 77: /* ConstDecl: ID ASSIGN Exp  */
#line 533 "src/parser.y"
                 {
        SymbolEntry *se;
        se = identifiers->lookup((yyvsp[-2].strtype));
        if(se!=nullptr&&dynamic_cast<IdentifierSymbolEntry*>(se)->getScope()==identifiers->getLevel()){
            fprintf(stderr,"identifier \"%s\" is redefined\n", (char*)(yyvsp[-2].strtype));
            delete [](char*)(yyvsp[-2].strtype);
            assert(se != nullptr);
        }else{
            se = new IdentifierSymbolEntry(TypeSystem::intType, (yyvsp[-2].strtype), identifiers->getLevel());
            //se->setConstant();
           
            ((IdentifierSymbolEntry*)se)->setValue((yyvsp[0].exprtype)->getValue());
             identifiers->install((yyvsp[-2].strtype), se);
            (yyval.stmttype) = new ConstDecl(new Id(se),(yyvsp[0].exprtype));
            delete [](yyvsp[-2].strtype);
        }
    }
#line 2080 "src/parser.cpp"
    break;

  case 78: /* ConstDecl: ID ArrayIndex ASSIGN ConstArrayVal  */
#line 550 "src/parser.y"
                                         {
        SymbolEntry* se;
        ExprNode* temp = (yyvsp[-2].exprtype);
        std::vector<int> vecIdx;
        while (temp) {
            vecIdx.push_back(temp->getValue());
            temp = (ExprNode*)(temp->getNext());
        }
        Type *type;
        while (!vecIdx.empty()) {
            type = new ArrayType(TypeSystem::intType, vecIdx.back());
            vecIdx.pop_back();
        }
        arrayType = (ArrayType*)type;
        se = new IdentifierSymbolEntry(type, (yyvsp[-3].strtype), identifiers->getLevel());
        int *p = new int[type->getSize()];  //设置整型空间 即长度*大小
        ((IdentifierSymbolEntry*)se)->setArrayValue(p);
        ((IdentifierSymbolEntry*)se)->setConst();
        identifiers->install((yyvsp[-3].strtype), se);
        /*if(!identifiers->install($1, se)){
            fprintf(stderr, "Variable \"%s\" redefinition\n", (char*)$1);
            exit(EXIT_FAILURE);
        }*/
        ((IdentifierSymbolEntry*)se)->setValue((yyvsp[0].exprtype)->getValue());
        (yyval.stmttype) = new ConstDecl(new Id(se), (yyvsp[0].exprtype));
        delete [](yyvsp[-3].strtype);
    }
#line 2112 "src/parser.cpp"
    break;

  case 79: /* $@3: %empty  */
#line 584 "src/parser.y"
                  {
        identifiers = new SymbolTable(identifiers);
        paramNo = 0;    //标记参数的id
    }
#line 2121 "src/parser.cpp"
    break;

  case 80: /* $@4: %empty  */
#line 589 "src/parser.y"
    {
        Type *funcType;
        std::vector<SymbolEntry*> vecSe;
        std::vector<Type*> vec;
        FuncParams* temp = (FuncParams*)(yyvsp[-1].exprtype);
        while(temp){
            vecSe.push_back(temp->getParam()->getSymPtr());
            vec.push_back(temp->getParam()->getSymPtr()->getType());
            temp = (FuncParams*)(temp->getNext());
        }
        // funcType = new FunctionType($1,vec);
        funcType = new FunctionType((yyvsp[-5].type), vec, vecSe);
        dynamic_cast<FunctionType*>(funcType)->setRetType((yyvsp[-5].type));
        std::string name = (yyvsp[-4].strtype)+std::__cxx11::to_string(vec.size());
        SymbolEntry *se = new IdentifierSymbolEntry(funcType, name, identifiers->getPrev()->getLevel());
        identifiers->getPrev()->install(name, se);       
        current = se;
    }
#line 2144 "src/parser.cpp"
    break;

  case 81: /* FuncDef: Type ID LPAREN $@3 FuncParams RPAREN $@4 BlockStmt  */
#line 606 "src/parser.y"
              {
        (yyval.stmttype) = new FunctionDef(current, (FuncParams*)(yyvsp[-3].exprtype), (yyvsp[0].stmttype));
        SymbolTable *top = identifiers;
        identifiers = identifiers->getPrev();
        delete top;
        delete [](yyvsp[-6].strtype);
    }
#line 2156 "src/parser.cpp"
    break;

  case 82: /* $@5: %empty  */
#line 615 "src/parser.y"
    {
        Type *funcType;
        funcType = new FunctionType((yyvsp[-3].type),{});
        dynamic_cast<FunctionType*>(funcType)->setRetType((yyvsp[-3].type));
        std::string zero="0";
        std::string name=(yyvsp[-2].strtype);
        if(name!="main"){
            name = (yyvsp[-2].strtype)+zero;
        }
        SymbolEntry *se = new IdentifierSymbolEntry(funcType, name, identifiers->getLevel());
        identifiers->install(name, se);
        identifiers = new SymbolTable(identifiers);
        current = se;
    }
#line 2175 "src/parser.cpp"
    break;

  case 83: /* FuncDef: Type ID LPAREN RPAREN $@5 BlockStmt  */
#line 628 "src/parser.y"
              {
        (yyval.stmttype) = new FunctionDef(current, nullptr, (yyvsp[0].stmttype));
        SymbolTable *top = identifiers;
        identifiers = identifiers->getPrev();
        delete top;
        delete [](yyvsp[-4].strtype);
    }
#line 2187 "src/parser.cpp"
    break;

  case 84: /* FuncParams: FuncParam  */
#line 639 "src/parser.y"
              {
        FuncParam* temp = (FuncParam*)(yyvsp[0].exprtype);
        int type = temp ->getId()->dst->getType()->getKind();
        
        Type* type1 = temp->getSymPtr()->getType();
        SymbolEntry *se = new TemporarySymbolEntry(type1, SymbolTable::getLabel());
        (yyval.exprtype)=new FuncParams(se,(yyvsp[0].exprtype),nullptr);
    }
#line 2200 "src/parser.cpp"
    break;

  case 85: /* FuncParams: FuncParam COMMA FuncParams  */
#line 648 "src/parser.y"
                               {
        FuncParam* temp = (FuncParam*)(yyvsp[-2].exprtype);
        int type = temp ->getId()->dst->getType()->getKind();
        Type* type1 = temp->getSymPtr()->getType();
        SymbolEntry *se = new TemporarySymbolEntry(type1, SymbolTable::getLabel());
        (yyval.exprtype)=new FuncParams(se,(yyvsp[-2].exprtype),(yyvsp[0].exprtype));
    }
#line 2212 "src/parser.cpp"
    break;

  case 86: /* FuncParam: Type ID  */
#line 659 "src/parser.y"
            {
        SymbolEntry *se;
        se = new IdentifierSymbolEntry((yyvsp[-1].type), (yyvsp[0].strtype), identifiers->getLevel());
        identifiers->install((yyvsp[0].strtype), se);
        (yyval.exprtype) = new FuncParam(se, new Id(se),nullptr);
        delete [](yyvsp[0].strtype);
    }
#line 2224 "src/parser.cpp"
    break;

  case 87: /* FuncParam: Type ID ASSIGN Exp  */
#line 667 "src/parser.y"
                      {
        SymbolEntry *se;
        se = new IdentifierSymbolEntry((yyvsp[-3].type), (yyvsp[-2].strtype), identifiers->getLevel());
        identifiers->install((yyvsp[-2].strtype), se);
        (yyval.exprtype) = new FuncParam(se, new Id(se),(yyvsp[0].exprtype));
        delete [](yyvsp[-2].strtype);
    }
#line 2236 "src/parser.cpp"
    break;

  case 88: /* FuncParam: Type ID FuncArrayIndex  */
#line 674 "src/parser.y"
                             {
        SymbolEntry* se;
        ExprNode* temp = (yyvsp[0].exprtype);
        std::stack<ExprNode*> stackIdx;
        Type *arr;
        while (temp) {
            stackIdx.push(temp);
            temp = (ExprNode*)(temp->getNext());
        }
        while (!stackIdx.empty()) {
            arr = new ArrayType(TypeSystem::intType, stackIdx.top()->getValue());
            stackIdx.pop();
        }
        se = new IdentifierSymbolEntry(arr, (yyvsp[-1].strtype), identifiers->getLevel());
        identifiers->install((yyvsp[-1].strtype), se);
        //下面这两句话感觉可能会用不到
        //((IdentifierSymbolEntry*)se)->setLabel();
        //((IdentifierSymbolEntry*)se)->setAddr(new Operand(se));
       // $$ = new DeclStmt(new Id(se));
        (yyval.exprtype) = new FuncParam(se,new Id(se),nullptr);
        delete [](yyvsp[-1].strtype);
    }
#line 2263 "src/parser.cpp"
    break;

  case 89: /* Istream: GETINT LPAREN RPAREN  */
#line 700 "src/parser.y"
    {
        SymbolEntry *se;
        se = identifiers->lookup("getint");
        SymbolEntry* thisSe= new IdentifierSymbolEntry(dynamic_cast<FunctionType*>(se->getType())->getRetType(), "getint", identifiers->getLevel());
        (yyval.exprtype)=new FuncCallExp(thisSe,se,nullptr);
    }
#line 2274 "src/parser.cpp"
    break;

  case 90: /* Istream: GETCH LPAREN RPAREN  */
#line 708 "src/parser.y"
    {
        SymbolEntry *se;
        se = identifiers->lookup("getch");
        SymbolEntry* thisSe= new IdentifierSymbolEntry(dynamic_cast<FunctionType*>(se->getType())->getRetType(), "getch", identifiers->getLevel());
        (yyval.exprtype)=new FuncCallExp(thisSe,se,nullptr);
    }
#line 2285 "src/parser.cpp"
    break;

  case 91: /* Istream: GETFLOAT LPAREN RPAREN  */
#line 716 "src/parser.y"
    {
        SymbolEntry *se;
        se = identifiers->lookup("getfloat");
        SymbolEntry* thisSe= new IdentifierSymbolEntry(dynamic_cast<FunctionType*>(se->getType())->getRetType(), "getfloat", identifiers->getLevel());
        (yyval.exprtype)=new FuncCallExp(thisSe,se,nullptr);
    }
#line 2296 "src/parser.cpp"
    break;

  case 92: /* Ostream: PUTINT LPAREN CallList RPAREN  */
#line 727 "src/parser.y"
    {
        SymbolEntry *se;
        se = identifiers->lookup("putint");
        SymbolEntry* thisSe= new IdentifierSymbolEntry(dynamic_cast<FunctionType*>(se->getType())->getRetType(), "putint", identifiers->getLevel());
        (yyval.exprtype)=new FuncCallExp(thisSe,se,(yyvsp[-1].exprtype));
    }
#line 2307 "src/parser.cpp"
    break;

  case 93: /* Ostream: PUTCH LPAREN CallList RPAREN  */
#line 735 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::voidType, SymbolTable::getLabel());
        se = identifiers->lookup("putch");
        SymbolEntry* thisSe= new IdentifierSymbolEntry(dynamic_cast<FunctionType*>(se->getType())->getRetType(), "putch", identifiers->getLevel());
        (yyval.exprtype)=new FuncCallExp(thisSe,se,(yyvsp[-1].exprtype));
    }
#line 2318 "src/parser.cpp"
    break;

  case 94: /* Ostream: PUTFLOAT LPAREN CallList RPAREN  */
#line 743 "src/parser.y"
    {
        SymbolEntry *se = new TemporarySymbolEntry(TypeSystem::voidType, SymbolTable::getLabel());
        se = identifiers->lookup("putfloat");
        SymbolEntry* thisSe= new IdentifierSymbolEntry(dynamic_cast<FunctionType*>(se->getType())->getRetType(), "putfloat", identifiers->getLevel());
        (yyval.exprtype)=new FuncCallExp(thisSe,se,(yyvsp[-1].exprtype));
    }
#line 2329 "src/parser.cpp"
    break;

  case 95: /* ArrayIndex: LBRACKET ConstExp RBRACKET  */
#line 756 "src/parser.y"
                                 {
        (yyval.exprtype) = (yyvsp[-1].exprtype);
    }
#line 2337 "src/parser.cpp"
    break;

  case 96: /* ArrayIndex: ArrayIndex LBRACKET ConstExp RBRACKET  */
#line 759 "src/parser.y"
                                            {
        (yyval.exprtype) = (yyvsp[-3].exprtype);
        (yyvsp[-3].exprtype)->setNext((yyvsp[-1].exprtype));//从左到右存多维数组的元素大小
    }
#line 2346 "src/parser.cpp"
    break;

  case 97: /* FuncArrayIndex: LBRACKET RBRACKET  */
#line 766 "src/parser.y"
                        {
        (yyval.exprtype) = new ExprNode(nullptr);
    }
#line 2354 "src/parser.cpp"
    break;

  case 98: /* FuncArrayIndex: RBRACKET Exp RBRACKET  */
#line 769 "src/parser.y"
                            {
        (yyval.exprtype) = (yyvsp[-1].exprtype);
    }
#line 2362 "src/parser.cpp"
    break;

  case 99: /* FuncArrayIndex: FuncArrayIndex RBRACKET Exp RBRACKET  */
#line 772 "src/parser.y"
                                           {
        (yyval.exprtype) = (yyvsp[-3].exprtype);
        (yyvsp[-3].exprtype)->setNext((yyvsp[-1].exprtype));//从左到右存多维数组的元素大小
    }
#line 2371 "src/parser.cpp"
    break;

  case 100: /* ArrayValList: ArrayVal  */
#line 779 "src/parser.y"
               {
        (yyval.exprtype) = (yyvsp[0].exprtype);
    }
#line 2379 "src/parser.cpp"
    break;

  case 101: /* ArrayValList: ArrayValList COMMA ArrayVal  */
#line 782 "src/parser.y"
                                  {
        (yyval.exprtype) = (yyvsp[-2].exprtype);
        (yyvsp[-2].exprtype)->setNext((yyvsp[0].exprtype));
    }
#line 2388 "src/parser.cpp"
    break;

  case 102: /* ArrayVal: Exp  */
#line 787 "src/parser.y"
          {
        (yyval.exprtype) = (yyvsp[0].exprtype);
    }
#line 2396 "src/parser.cpp"
    break;

  case 103: /* ArrayVal: LBRACE RBRACE  */
#line 790 "src/parser.y"
                    {
        SymbolEntry *se = new ConstantSymbolEntry(TypeSystem::intType, 0);
        (yyval.exprtype) = new Constant(se);
    }
#line 2405 "src/parser.cpp"
    break;

  case 104: /* ArrayVal: LBRACE ArrayValList RBRACE  */
#line 794 "src/parser.y"
                                 {
        (yyval.exprtype) = (yyvsp[-1].exprtype);
    }
#line 2413 "src/parser.cpp"
    break;

  case 105: /* ConstArrayValList: ConstArrayVal  */
#line 799 "src/parser.y"
                    {
        (yyval.exprtype) = (yyvsp[0].exprtype);
    }
#line 2421 "src/parser.cpp"
    break;

  case 106: /* ConstArrayValList: ConstArrayValList COMMA ConstArrayVal  */
#line 802 "src/parser.y"
                                            {
        (yyval.exprtype) = (yyvsp[-2].exprtype);
        (yyvsp[-2].exprtype)->setNext((yyvsp[0].exprtype));
    }
#line 2430 "src/parser.cpp"
    break;

  case 107: /* ConstArrayVal: Exp  */
#line 807 "src/parser.y"
          {
        (yyval.exprtype) = (yyvsp[0].exprtype);
    }
#line 2438 "src/parser.cpp"
    break;

  case 108: /* ConstArrayVal: LBRACE RBRACE  */
#line 810 "src/parser.y"
                    {
        SymbolEntry *se = new ConstantSymbolEntry(TypeSystem::intType, 0);
        (yyval.exprtype) = new Constant(se);
    }
#line 2447 "src/parser.cpp"
    break;

  case 109: /* ConstArrayVal: LBRACE ConstArrayValList RBRACE  */
#line 814 "src/parser.y"
                                      {
        (yyval.exprtype) = (yyvsp[-1].exprtype);
    }
#line 2455 "src/parser.cpp"
    break;

  case 110: /* CallList: Exp  */
#line 839 "src/parser.y"
    {
        (yyval.exprtype)=new CallList(nullptr,(yyvsp[0].exprtype),nullptr);
    }
#line 2463 "src/parser.cpp"
    break;

  case 111: /* CallList: Exp COMMA CallList  */
#line 844 "src/parser.y"
    {
        (yyval.exprtype)=new CallList(nullptr,(yyvsp[-2].exprtype),(yyvsp[0].exprtype));
    }
#line 2471 "src/parser.cpp"
    break;

  case 112: /* FuncCallExp: ID LPAREN RPAREN  */
#line 852 "src/parser.y"
    {
        SymbolEntry *se;
        std::string zero="0";//没有参数的
        std::string name=(yyvsp[-2].strtype)+zero;
        se = identifiers->lookup(name);
        if(se==nullptr){
            fprintf(stderr,"identifier \"%s\" is undefined\n", (char*)(yyvsp[-2].strtype));
            delete [](char*)(yyvsp[-2].strtype);
            assert(se != nullptr);
        }
        
        SymbolEntry* thisSe= new IdentifierSymbolEntry(dynamic_cast<FunctionType*>(se->getType())->getRetType(), (yyvsp[-2].strtype), identifiers->getLevel());

        (yyval.exprtype)=new FuncCallExp(thisSe,se,nullptr);
    }
#line 2491 "src/parser.cpp"
    break;

  case 113: /* FuncCallExp: ID LPAREN CallList RPAREN  */
#line 869 "src/parser.y"
    {
        SymbolEntry *se;
        std::vector<ExprNode*> vec;//参数
        ExprNode* temp = (yyvsp[-1].exprtype); // calllist（实参）
        while(temp){
            ExprNode *tempParam = dynamic_cast<CallList*>(temp)->getParam();//获取参数
            vec.push_back(tempParam);
            temp = dynamic_cast<CallList*>(temp)->getNext();
        }
        std::string name=(yyvsp[-3].strtype)+std::__cxx11::to_string(vec.size()); //vec.size()是参数个数
        se = identifiers->lookup(name);
        if(se==nullptr){
            fprintf(stderr,"identifier \"%s\" with %dparam(s) is undefined\n", (char*)(yyvsp[-3].strtype),vec.size());
            delete [](char*)(yyvsp[-3].strtype);
            assert(se != nullptr);
        }
        SymbolEntry* thisSe= new IdentifierSymbolEntry(dynamic_cast<FunctionType*>(se->getType())->getRetType(), (yyvsp[-3].strtype), identifiers->getLevel());
        (yyval.exprtype)=new FuncCallExp(thisSe,se,(yyvsp[-1].exprtype));
    }
#line 2515 "src/parser.cpp"
    break;

  case 114: /* FuncCallExp: Istream  */
#line 889 "src/parser.y"
           {(yyval.exprtype) = (yyvsp[0].exprtype);}
#line 2521 "src/parser.cpp"
    break;

  case 115: /* FuncCallExp: Ostream  */
#line 891 "src/parser.y"
           {(yyval.exprtype) = (yyvsp[0].exprtype);}
#line 2527 "src/parser.cpp"
    break;


#line 2531 "src/parser.cpp"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 894 "src/parser.y"


int yyerror(char const* message)
{
    std::cerr<<message<<std::endl;
    return -1;
}
